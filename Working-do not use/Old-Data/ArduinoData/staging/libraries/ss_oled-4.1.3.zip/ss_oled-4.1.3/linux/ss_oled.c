// The C++ code is really C code, so just include it
// to make the compiler treat it as C

#include "../src/ss_oled.cpp"

