// The C++ code is really C code, so just include it
// to make the compiler treat it as C

#include "../src/BitBang_I2C.cpp"

