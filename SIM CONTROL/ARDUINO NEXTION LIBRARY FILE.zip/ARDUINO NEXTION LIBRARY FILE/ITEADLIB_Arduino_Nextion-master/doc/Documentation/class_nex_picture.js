var class_nex_picture =
[
    [ "NexPicture", "class_nex_picture.html#aa6096defacd933e8bff5283c83200459", null ],
    [ "Get_background_image_pic", "class_nex_picture.html#a0297c4a9544df9b0c37db0ea894d699f", null ],
    [ "getPic", "class_nex_picture.html#a11bd68ef9fe1d03d9e0d02ef1c7527e9", null ],
    [ "Set_background_image_pic", "class_nex_picture.html#a531e22f70dbf0dcaf6e114581364acea", null ],
    [ "setPic", "class_nex_picture.html#ab1c6adff615d48261ce10c2095859abd", null ]
];