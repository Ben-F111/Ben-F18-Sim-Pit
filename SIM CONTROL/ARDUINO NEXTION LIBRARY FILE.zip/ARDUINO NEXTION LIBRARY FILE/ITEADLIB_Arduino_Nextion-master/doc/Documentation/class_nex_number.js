var class_nex_number =
[
    [ "NexNumber", "class_nex_number.html#a59c2ed35b787f498e7fbc54eff71d00b", null ],
    [ "Get_background_color_bco", "class_nex_number.html#aa7ef40e79d89eb0aeebbeb67147a0d20", null ],
    [ "Get_background_crop_picc", "class_nex_number.html#a9772a6717c19c5a03ea0e33ff71492d9", null ],
    [ "Get_background_image_pic", "class_nex_number.html#a9f235a8929b4f6c282511c04c88216c1", null ],
    [ "Get_font_color_pco", "class_nex_number.html#a7eb3fba2bfa2fff8df8e7e0f633f9cf9", null ],
    [ "Get_number_lenth", "class_nex_number.html#a0dfc73db91229f114e502bc14084e711", null ],
    [ "Get_place_xcen", "class_nex_number.html#a7ca05534f06911218bae6606ccc355fa", null ],
    [ "Get_place_ycen", "class_nex_number.html#ac8f0cef0d04e72bb864f6da88f028c9f", null ],
    [ "getFont", "class_nex_number.html#a8ccd35555397e828cf8b1f0a8e9ba294", null ],
    [ "getValue", "class_nex_number.html#ad184ed818666ec482efddf840185c7b8", null ],
    [ "Set_background_color_bco", "class_nex_number.html#a8168c315e57d9aec3b61ed4febaa6663", null ],
    [ "Set_background_crop_picc", "class_nex_number.html#a410bd4092a5874541da654edd86a01eb", null ],
    [ "Set_background_image_pic", "class_nex_number.html#aa45acacbde526fce04c699104114d1f1", null ],
    [ "Set_font_color_pco", "class_nex_number.html#ab1836d2d570fca4cd707acecc4b67dea", null ],
    [ "Set_number_lenth", "class_nex_number.html#a045519a466875775d561e54176c459ad", null ],
    [ "Set_place_xcen", "class_nex_number.html#a5e58200c740340cc2666e61b6c80e891", null ],
    [ "Set_place_ycen", "class_nex_number.html#a05aa6572aabe07b48c1b0675904aaadd", null ],
    [ "setFont", "class_nex_number.html#aed567aef79411c5457c81be272218439", null ],
    [ "setValue", "class_nex_number.html#a9cef51f6b76b4ba03a31b2427ffd4526", null ]
];