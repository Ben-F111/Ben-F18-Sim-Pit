# Nextion
Class interface for Nextion LCD

## TESTED ON

arduino uno

arduino nano

esp8266 d1 mini

nextion BASIC 3.2

## NOT TESTED

upload(); // upload multiple bytes

write(); // write 1 byte in upload

open(); // initiate device for upload 
