F/A-18C Kneeboard Suite - Checklists, Quickstart, Ordnance - Updated 11 February 2022

Realistic checklists, a quickstart guide, the full list of weapons, BRA helper, and more.

CHANGELOG

11 February 2022
- Ordnance page reworked: ordnance weight added, HAFU helper replaced with BRA helper.

12 January 2022
- Numerous corrections and improvements across the board.
- Made all night kneeboards significantly darker.

DESCRIPTION

This collection of checklists is based on the real-world procedures as closely as practicable for the DCS environment. I took the original NATOPS checklist, carefully removed all the excessive parts (such as the cockpit preparations and passive checks), and further polished it with Tricker's videos that he made with the help from the real Hornet pilots.

Also included are the full list of weapons with their DDI codes and weight, the combat checks (inspired by the Navy's Tactical Manual for the Hornet), the BRA/Bullseye symbology helper, and a handy table explaining the tricky art of the exterior lighting.

Finally, there is a bonus "Quickstart" page that will allow you to properly get the jet up and running in 29 easy steps (zero aircraft knowledge required).

HOW TO INSTALL

Copy the "FA-18C_hornet" folder into your "Saved Games\DCS (or DCS.openbeta)\KNEEBOARD\" directory. You may need to create the "KNEEBOARD" folder if it doesn't exist.

THERE'S MORE!

This Kneeboard Suite is designed as a three-part package. You can complement it with two additional downloads:
* F/A-18C Kneeboard Suite - CASE I/II/III Charts, Overhead Break, LSO grades - https://www.digitalcombatsimulator.com/en/files/3314314/
* F/A-18C Kneeboard Suite - RWR Threats, HARM Radar Codes - https://www.digitalcombatsimulator.com/en/files/3314315/

The complete Suite, with all three parts combined, as a single iPad-optimized PDF file:
* Day variant - http://www.minsky.ru/dimon/files/FA-18C_Kneeboard_Suite_Day_by_DimOn_latest.pdf
* Night variant - http://www.minsky.ru/dimon/files/FA-18C_Kneeboard_Suite_Night_by_DimOn_latest.pdf

SPECIAL THANKS

MARLAN_, Xamik75

CONTACT INFO

Feedback and updates: https://forums.eagle.ru/topic/266375-fa-18c-kneeboard-suite-by-dimon/

Created by Dmitriy Kozyrev
dimkzr@gmail.com
